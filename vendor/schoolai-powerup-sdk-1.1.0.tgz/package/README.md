# How to make a PowerUp

## What is a PowerUp?

A PowerUp is a web application that extends Dot's capabilities. PowerUps can:
- Maintain their own state between sessions
- Respond to commands from Dot
- Display interactive UI to users
- Access context about the current chat
- Communicate results back to Dot

PowerUps are built as static web applications, which means they run entirely in the browser without needing a backend server. When you submit a PowerUp for approval, we host it on our CDN for all users to access.

## Getting Started

Before diving into development, you'll need:

1. Node.js installed (version 22 or higher recommended)
2. To build the PowerUp SDK locally (temporary requirement until we publish to npm):
   ```sh
   git clone https://github.com/schoolai/powerup-sdk.git
   cd powerup-sdk
   npm install
   npm run pack:local
   ```

3. Choose your development environment:

   **Modern: TypeScript + Vite (Recommended)**
   ```sh
   # Create and set up a Vite project
   npm create vite@latest my-powerup -- --template vanilla-ts
   cd my-powerup
   npm install

   # Install the SDK from your local build
   npm install /path/to/powerup-sdk/tarballs/schoolai-powerup-sdk-1.1.0.tgz
   ```
   With this approach, you'll import the SDK as an npm package.

   **Basic: HTML + JS**
   ```sh
   # First, build and serve the SDK
   cd powerup-sdk
   npm run build:cdn
   npm run serve:cdn  # Keep this running during development
   ```
   ```html
   <!-- In your HTML file -->
   <script src="http://localhost:8090/powerup-sdk-v1.1.0.js"></script>
   <script type="importmap">
     {
       "imports": {
         "@schoolai/powerup-sdk": "./powerup-sdk-shim.js"
       }
     }
   </script>
   ```

   Create a `powerup-sdk-shim.js` file to bridge between the IIFE bundle and ESM imports:
   ```js
   export const Client = window.PowerupSDK.Client;
   export const createPowerUpSessionManager = window.PowerupSDK.createPowerUpSessionManager;
   ```

   Then in your JavaScript file, you can use ESM imports:
   ```js
   import { Client } from '@schoolai/powerup-sdk'

   const client = new Client({
     // ... your config here
   });
   ```
   This approach serves the SDK directly via a script tag. You must keep `serve:cdn` running during development.

Note: The SDK building steps above are temporary. Once we publish to npm, you'll simply run `npm install @schoolai/powerup-sdk`.

The SDK includes a development sandbox that makes testing and debugging much faster - you'll learn more about this in the Testing section below.

## Understanding RPCs

RPCs (Remote Procedure Calls) are how Dot interacts with your PowerUp. When a user asks Dot to do something with your PowerUp, Dot calls one of your RPCs. For example:

User: "Set the counter to 5"
↓
Dot calls your `setCount` RPC with `{ count: 5 }`
↓
Your PowerUp updates its state and UI
↓
Your RPC returns a detailed message explaining what happened

Every PowerUp must have at least one RPC (usually `open`). RPCs should:
- Validate their input parameters
- Return descriptive messages about what they did
- Handle errors gracefully
- Keep Dot informed about state changes

## Building the most minimal PowerUp

A PowerUp is just a static web app. At minimum it is just an HTML file and a JS file. Let's start with a very basic
HTML file:

```html
<!doctype html>
<html lang="en">
  <head>
    <script type="importmap">
      {
        "imports": {
          "@schoolai/powerup-sdk": "http://localhost:8090/powerup-sdk-v1.0.0.js",
          "zod": "https://unpkg.com/zod@^4/index.js"
        }
      }
    </script>
    <script type="module" src="main.js"></script>
  </head>
  <body>
    <div id="app">
      <button id="counter" type="button"></button>
    </div>
  </body>
</html>
```

In your main.js, you'll need to import and construct our Client.

```js
import { Client } from '@schoolai/powerup-sdk'
const client = new Client({
  rpcHandlers: {
    async open() {
      return {
        isError: false,
        content: [{ type: 'text', text: 'done' }],
      }
    },
  },
  hooks: {
    async onInitialize() {}
  }
})
await client.init()
```

When we load your PowerUp, we wait for your PowerUp to call client.init(). When you do, we do some
handshake stuff with your PowerUp and eventually call onInitialize. When that completes, your PowerUp
will be displayed. You also must have at least one RPC. An RPC is how Dot interacts with your PowerUp.
Without at least an open RPC, Dot won't be able to use your PowerUp.

The return values from your RPCs are consumed by Dot's AI to understand what happened. Always return detailed,
descriptive text that explains what the RPC did, what changed in your PowerUp, and what the user might have
seen. This helps the AI maintain accurate context about your PowerUp's state and provide better assistance.

Finally, we need to create a manifest file (`manifest.json`). This file is crucial as it:
- Tells Dot how to find and run your PowerUp
- Defines what commands (RPCs) your PowerUp supports
- Provides metadata like name, description, and styling
- Sets permissions and configuration

Here's a basic manifest:

```json
{
    "name": "Counter",
    "slug": "counter",
    "description": "Displays the number 0 initially. Clicking the button increments the count.",
    "useCase": "Teach basic counting skills.",
    "author": "SchoolAI",
    "authorEmail": "support@schoolai.com",
    "icon": "type-02",
    "bgColor": "bg-blue-100",
    "bgHover": "bg-blue-200",
    "color": "text-blue-700",
    "semanticVersion": "1.0.0",
    "entrypoint": "",
    "powerupMCPSpecification": {
        "tools": [
            {
                "name": "open",
                "description": "Open the counter",
                "inputSchema": {
                    "type": "object",
                    "properties": {},
                    "required": []
                }
            }
        ]
    },
    "permissions": {},
    "published": true,
    "assetUrl": "http://localhost:5201/"
}
```

## Testing Your PowerUp

There are two main ways to test your PowerUp during development:

### Using the Development Sandbox

The SDK includes a powerful sandbox environment that allows you to test your PowerUp quickly and directly, without going through Dot. The sandbox provides:

- **Direct PowerUp Management**: Add, update, and remove PowerUps by pasting their manifest JSON
- **Multiple Sessions**: Test multiple instances of your PowerUp simultaneously
- **Direct RPC Testing**: Trigger RPC calls directly without chat interactions
- **State Management**: View and manipulate PowerUp state
- **Development Environment**: Simulated auth tokens and chat context

To use the sandbox:

1. Start your PowerUp's development server (see hosting options below)
2. Open the sandbox in your browser:
   ```sh
   cd powerup-sdk
   npm run sandbox
   ```
3. Add your PowerUp by pasting its manifest JSON into the "Add/Update PowerUp" form
4. Create a new session for your PowerUp
5. Test RPCs and view state changes directly

The sandbox is particularly useful for:
- Rapid development and debugging
- Testing edge cases and error handling
- Verifying state management
- Testing multiple PowerUp instances

### Testing with Dot Integration

While the sandbox is great for rapid development, you should also test your PowerUp in the full Dot environment before submitting it. This ensures it works correctly in the production context and with Dot interactions.

First, you'll need to host your PowerUp over HTTP at the location specified in assetUrl in the manifest. You can use any of these hosting options:

**Quick Start: Use the included development server**
```sh
cd examples
node server.js minimal  # Replace 'minimal' with your PowerUp's directory
```
This development server:
- Automatically reads the port from your manifest.json
- Prevents aggressive browser caching
- Watches for file changes and auto-reloads
- Supports multiple PowerUps (just pass multiple directory names)

**Alternative: Python's simple HTTP server**
```sh
python3 -m http.server 5201
```
Note: This method has aggressive browser caching which can make development frustrating.

**Alternative: Vite's dev server**
If you're using the Vite template:
```sh
npm run dev
```

These are just examples for local development - you can use any web server or hosting method you're comfortable with
during development, as long as your PowerUp is accessible at the URL specified in your manifest.json. Remember that
for production, your PowerUp will be hosted by SchoolAI, not your own server.

To test with Dot:

1. Head to https://app.schoolai.com/
2. Press [Cmd or Ctrl] + [Shift] + [Y] to open the debug panel
3. Click on the green External PowerUps button
4. Copy/paste your manifest file contents into the "Add/Update PowerUp" form and click "Add/Update PowerUp"
5. Refresh the page

You can now ask Dot to open your PowerUp with something like "Open the counter PowerUp".

## Manifest Specification

Every PowerUp requires a `manifest.json` file that defines its metadata, capabilities, and requirements. This section details all manifest fields and their usage.

- `name` (string): Display name of your PowerUp
- `slug` (string): Unique identifier for your PowerUp (lowercase, no spaces)
- `description` (string): Brief description of what your PowerUp does
- `assetUrl` (string): URL where your PowerUp is hosted (during development)
- `semanticVersion` (string): Version number following semver format (e.g., "1.0.0")
- `powerupMCPSpecification`: Object defining your PowerUp's RPC interface
  - `tools`: Array of RPC definitions
    - Each tool must have:
      - `name` (string): RPC function name
      - `description` (string): What the RPC does
      - `inputSchema`: JSON Schema defining the RPC's parameters
        - `type`: Usually "object"
        - `properties`: Parameter definitions
        - `required`: Array of required parameter names
- `useCase` (string): Detailed explanation of when to use your PowerUp
- `author` (string): Your name or organization
- `authorEmail` (string): Contact email for support/issues
- `icon` (string): Icon identifier (see UI guidelines)
- `bgColor` (string): Background color class (e.g., "bg-blue-100")
- `bgHover` (string): Hover state color class (e.g., "bg-blue-200")
- `color` (string): Text color class (e.g., "text-blue-700")
- `permissions` (object): Required permissions (if any)
- `published` (boolean): Whether the PowerUp is ready for production

### Example Manifest

```json
{
  "name": "Counter",
  "slug": "counter",
  "description": "A simple counter PowerUp that demonstrates basic functionality",
  "useCase": "Teaching basic counting and demonstrating PowerUp capabilities",
  "author": "SchoolAI",
  "authorEmail": "support@schoolai.com",
  "icon": "type-02",
  "bgColor": "bg-blue-100",
  "bgHover": "bg-blue-200",
  "color": "text-blue-700",
  "semanticVersion": "1.0.0",
  "assetUrl": "http://localhost:5201/",
  "powerupMCPSpecification": {
    "tools": [
      {
        "name": "open",
        "description": "Opens the counter PowerUp",
        "inputSchema": {
          "type": "object",
          "properties": {},
          "required": []
        }
      },
      {
        "name": "setCount",
        "description": "Sets the counter to a specific value",
        "inputSchema": {
          "type": "object",
          "properties": {
            "count": {
              "type": "number",
              "description": "The value to set the counter to"
            }
          },
          "required": ["count"]
        }
      }
    ]
  },
  "permissions": {},
  "published": true
}
```

### Best Practices

1. **RPC Definitions**:
   - Give each RPC a clear, descriptive name
   - Write detailed descriptions that help Dot understand when to use each RPC
   - Define parameter schemas precisely to ensure proper validation

2. **Versioning**:
   - Use semantic versioning (MAJOR.MINOR.PATCH)
   - Increment appropriately:
     - MAJOR: Breaking changes to RPC interface
     - MINOR: New features, backward compatible
     - PATCH: Bug fixes, backward compatible

3. **Asset URL**:
   - During development: Use localhost URL (e.g., "http://localhost:5201/")
   - For production: Leave empty or use placeholder - SchoolAI will set this

4. **Permissions**:
   - Only request permissions your PowerUp actually needs
   - Document why each permission is required
   - Consider security implications

## Core Concepts

### State Management

PowerUps can persist state between sessions using the client's state management capabilities. This allows your PowerUp to maintain its state even after being closed and reopened. Here's how to implement state management:

1. In your `onInitialize` hook, implement state loading and initialization:
```js
const onInitialize = async (client) => {
  // Try to load existing state
  const rawState = await client.getState()
  
  if (rawState.data != null) {
    // We have existing state from a previous session
    updateAppState(rawState.data)
  } else {
    // First time use - set up initial state
    const initialState = { count: 0 }
    await client.updateState({ data: initialState })
    updateAppState(initialState)
  }
}
```

2. Whenever your state changes, call `client.updateState()`:
```js
function onStateChange(newState) {
  // Update your UI here
  renderUI(newState)
  
  // Persist state to server
  client.updateState({ data: newState })
}
```

This pattern ensures that:
- First-time users get a proper initial state
- Returning users get their previous state restored
- All state changes are persisted to the server

## Using a Bundler (Vite)

While you can build PowerUps with plain HTML and JavaScript, using a modern bundler like Vite provides benefits like TypeScript support, hot module reloading during development, and optimized production builds. Here's how to create a minimal PowerUp using Vite:

1. Create a new Vite project:
```sh
npm create vite@latest my-powerup -- --template vanilla-ts
cd my-powerup
```

2. Install dependencies:
```sh
npm install

# Temporarily, until we publish to npm, install the SDK locally:
cd /path/to/powerup-sdk
npm run pack:local
cd /path/to/my-powerup
npm install /path/to/powerup-sdk/tarballs/schoolai-powerup-sdk-1.0.0.tgz
```

3. Update `index.html`:
```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My PowerUp</title>
  </head>
  <body>
    <div id="app">
      <button id="counter" type="button"></button>
    </div>
    <script type="module" src="/src/main.ts"></script>
  </body>
</html>
```

4. Update `src/main.ts`:
```ts
import { Client } from '@schoolai/powerup-sdk'

const client = new Client({
  rpcHandlers: {
    async open() {
      return {
        isError: false,
        content: [{ type: 'text', text: 'done' }],
      }
    },
  },
  hooks: {
    async onInitialize(client) {
      const rawState = await client.getState()
      // ... state management as shown in previous section
    }
  }
})

await client.init()
```

5. During development:
```sh
npm run dev
```

6. For production build:
```sh
npm run build
```

Important notes:
- Your PowerUp must be able to run as a static bundle. When you submit your PowerUp for approval, we will host it on our CDN without any backend server.
- The production build (in the `dist` directory) should contain everything needed to run your PowerUp.
- Make sure your `vite.config.ts` builds for production correctly:
```ts
import { defineConfig } from 'vite'

export default defineConfig({
  build: {
    // Ensure assets are included in the build
    assetsInlineLimit: 0,
  }
})
```

You can find a complete Vite example in the `examples/vite-vanilla-ts` directory.

## Available Hooks

The PowerUp SDK provides several hooks that allow you to respond to various lifecycle events. Here are all the available hooks:

#### Required Hooks

- `onInitialize: (client: Client) => Promise<void>`
  - Called after the initial handshake completes
  - Use this to perform any asynchronous initialization (fetching/setting state)
  - The PowerUp won't receive any RPC calls until this hook completes
  - You must implement this hook

#### Optional Hooks

- `onShow: () => Promise<void>`
  - Called when your PowerUp becomes visible
  - Use this to resume animations or update stale data

- `onHide: () => Promise<void>`
  - Called when your PowerUp is hidden but not destroyed
  - Use this to pause animations or stop unnecessary updates

- `onDestroy: () => Promise<void>`
  - Called when your PowerUp is being completely removed
  - Use this for cleanup (stopping timers, closing connections)

- `onResize: () => Promise<void>`
  - Called when your PowerUp's container is resized
  - Use this to adjust your layout if needed

- `onArtifactDidUpdate: (args: { artifactID: string, versionID: string }) => Promise<void>`
  - Called when an artifact your PowerUp is working with has been updated
  - Use this to refresh your PowerUp's view of the artifact

- `onBeforeSendMessage: (message: string) => Promise<void>`
  - Called before a message entered by the user is set to Dot

Example using multiple hooks:
```ts
const client = new Client({
  rpcHandlers: {
    // ... your RPC handlers
  },
  hooks: {
    async onInitialize(client) {
      // Load initial state
      const rawState = await client.getState()
      // ... initialize your PowerUp
    },
    async onShow() {
      startAnimations()
      startAudio()
    },
    async onHide() {
      pauseAnimations()
      pauseAudio()
    },
    async onDestroy() {
      // Clean up any resources
      clearAllTimers()
    }
  }
})
```

## Client API Methods

The Client instance provides several methods for managing state, controlling the UI, and interacting with the host environment.

#### State Management

- `getState(id?: 'latest' | string): Promise<State>`
  - Retrieves PowerUp state
  - Use `'latest'` (default) for current state or a specific version ID
  - Returns `{ data: YourStateType | null }`

- `updateState({ id?: 'latest' | string, data: any }): Promise<State>`
  - Updates PowerUp state
  - Use `'latest'` (default) to update current state
  - The entire state object is replaced with the new data

- `createStateVersion({ data: any }): Promise<State>`
  - Creates a new version of the state
  - Useful for creating save points or history

- `listStateVersions(): Promise<State[]>`
  - Returns all versions of your PowerUp's state
  - Ordered from newest to oldest

#### UI Control

- `hide(): Promise<void>`
  - Hides your PowerUp
  - Useful when your PowerUp has completed its task

- `setIsMaximized(isMaximized: boolean): Promise<void>`
  - Toggles maximized state of your PowerUp
  - Use this to request more screen space when needed

- `navigateTo(path: string, args?: unknown): Promise<void>`
  - Navigates to a different route in the host application
  - Use this carefully as it affects the user's navigation

#### Context and Authentication

- `getUserAuthToken(): Promise<string | null>`
  - Returns the user's authentication token if available
  - Use this for making authenticated requests

- `getChatContext(): Promise<{ chatId: string | null, collectionId: string | null, ... }>`
  - Returns information about the current chat context
  - Includes chat ID, collection ID, and other relevant data

- `getParentOrigin(): Promise<string>`
  - Returns the origin of the parent window
  - Useful for security validations

Example using multiple API methods:
```ts
const client = new Client({
  rpcHandlers: {
    async maximize() {
      // Save state before maximizing
      await client.updateState({ 
        data: { wasMaximized: true } 
      })
      
      // Show PowerUp in full screen
      await client.setIsMaximized(true)
      
      return {
        isError: false,
        content: [{ type: 'text', text: 'Maximized' }]
      }
    }
  },
  hooks: {
    async onInitialize(client) {
      // Get user context
      const token = await client.getUserAuthToken()
      const context = await client.getChatContext()
      
      // Load state
      const state = await client.getState()
      if (!state.data) {
        await client.updateState({
          data: { initialized: true }
        })
      }
    }
  }
})
```

## Error Handling

PowerUps should handle errors gracefully to provide a good user experience. There are two main types of errors you'll need to handle:

#### RPC Handler Errors

Your RPC handlers communicate with Dot's AI, so their return values should be as descriptive as possible. The AI uses these responses to understand:
- What action was performed
- What changed in your PowerUp's state
- What the user would have seen
- Whether there were any errors or limitations
- What options are available next

When an RPC handler encounters an error, return an error response instead of throwing. Make the error message clear and informative:

```ts
const client = new Client({
  rpcHandlers: {
    async setCount(params) {
      // Validate parameters
      if (typeof params.count !== 'number') {
        return {
          isError: true,
          content: [{ 
            type: 'text', 
            text: 'Unable to update counter: the provided count value was not a number. The counter remains at its previous value. Please provide a valid number to update the counter.' 
          }]
        }
      }

      try {
        await client.updateState({ 
          data: { count: params.count } 
        })
        
        return {
          isError: false,
          content: [{ 
            type: 'text', 
            text: `Successfully updated the counter to ${params.count}. The new value is now displayed in the UI. The counter can be further increased or decreased as needed.` 
          }]
        }
      } catch (error) {
        // Handle unexpected errors
        return {
          isError: true,
          content: [{ 
            type: 'text', 
            text: 'An error occurred while trying to update the counter. The counter value remains unchanged. This may be due to a temporary issue - you can try updating the counter again, or if the problem persists, try refreshing the PowerUp.' 
          }]
        }
      }
    }
  }
})
```

#### Client Method Errors

Client methods like `getState`, `updateState`, etc. return Promises that may reject. Handle these appropriately:

```ts
async function initializeState() {
  try {
    const state = await client.getState()
    
    if (!state.data) {
      await client.updateState({
        data: { count: 0 }
      })
    }
  } catch (error) {
    // Log error for debugging
    console.error('Failed to initialize state:', error)
    
    // Show user-friendly error UI
    showErrorMessage('Failed to load PowerUp state')
    
    // Optionally hide the PowerUp
    await client.hide()
  }
}
```

#### Best Practices

1. Always validate RPC parameters before using them
2. Return user-friendly error messages in RPC responses
3. Catch errors from all client method calls
4. Log errors for debugging but show user-friendly messages
5. Preserve state consistency when handling errors (e.g., rollback changes if a multi-step operation fails)
6. Make RPC responses AI-friendly by including:
   - What action was performed or attempted
   - The current state after the action
   - What changed visually for the user
   - Any new options or actions now available
   - Clear context for error conditions

